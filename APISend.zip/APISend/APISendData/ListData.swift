//
//  ListData.swift
//  APISendData
//
//  Created by edilsonalmeida on 27/04/23.
//

import SwiftUI

struct ListData: View {
    @StateObject var viewModel = ViewModel()
    
    @State var bool = false
    @State var Cantor = ""
    @State var AnoMusica = ""
    @State var NomeMusica = ""
    @State var Youtube = ""
    
    var body: some View {
        NavigationView{
            VStack{
                Text("\(viewModel.listPersonMusic.count)")
                List{
                    ForEach(viewModel.listPersonMusic, id: \._id){ pm in
                        NavigationLink(destination: DataDetail(pm: pm)){
                            Text("\(pm.nome) - " + " \(pm.ano) - " + "\(pm.musica)")
                        }
                        
                    }
                    .onDelete(perform: viewModel.remove)
                }
                
                Button("Adicionar Música") {
                    bool.toggle()
                }
                .padding()
                
            }.onAppear(){
                Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true){_ in 
                    viewModel.fetch()
                }
                
            }.sheet(isPresented: $bool, content: {
                TextField("Cantor", text: $Cantor)
                TextField("Ano Musica", text: $AnoMusica)
                TextField("Nome Música", text: $NomeMusica)
                TextField("Link Youtube", text: $Youtube)
                
                Button("Salvar"){
                    
                    
                    viewModel.post(PersonMusic(nome: Cantor, ano: Int(AnoMusica) ?? 1967, musica: NomeMusica, linkMusica: Youtube))
                }
            })
            
            
        }
        .navigationBarTitle("My MusicPerson")
    }
    
}

struct ListData_Previews: PreviewProvider {
    static var previews: some View {
        ListData()
    }
}
