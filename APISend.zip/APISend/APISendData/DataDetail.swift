//
//  ContentView.swift
//  APISendData
//
//  Created by edilsonalmeida on 26/04/23.
//

import SwiftUI

struct DataDetail: View {
    
    @State var pm : PersonMusic

    
    var body: some View {
        VStack {
            Text(pm.musica)
           
            WebView(url: URL(string: pm.linkMusica)!)
            
            
            
        }
        .padding()
    }
    
    func Atualizar() async {
    }
}

struct DataDetail_Previews: PreviewProvider {
    static var previews: some View {
        var p = PersonMusic(_id: "teste", _rev: "teste", nome: "edilson", ano: 26, musica: "Blue Boy", linkMusica: "https://www.youtube.com/watch?v=AR_R1kt4V54")
        DataDetail(pm: p)
        
        
    }
}
