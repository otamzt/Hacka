//
//  APISendDataApp.swift
//  APISendData
//
//  Created by edilsonalmeida on 26/04/23.
//

import SwiftUI

@main
struct APISendDataApp: App {
    var body: some Scene {
        WindowGroup {
            ListData()
        }
    }
}
